
/*

Copyright (C) 2019,2020  Yusuf Kağan Hanoğlu

  This file is part of SensorCamera.

    SensorCamera is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    SensorCamera is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SensorCamera.  If not, see <https://www.gnu.org/licenses/>.*/


package com.hanoglu.sensorkamera;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.hanoglu.sensorkamera.R;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CameraSettings extends Activity {



    CheckBox kayit,onizle,dusuk,opencvfps;
    RadioButton rb1,rb3,rb5,rb15,rb30,rb2,rb6,rb10;
    int obj_selected = 0;


    boolean kayit_bool = false;
    boolean onizle_bool = false;
    boolean dusuk_bool = false;
    boolean opencvfps_bool = false;


    Button surum;TextView hakkinda;


    @Override
    public void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);

        setContentView(R.layout.camerasettings);

        kayit = findViewById(R.id.kayit);
        onizle = findViewById(R.id.onizle);
        dusuk = findViewById(R.id.dusuk);
        opencvfps = findViewById(R.id.opencvfps);




        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        rb5 = findViewById(R.id.rb5);
        rb6 = findViewById(R.id.rb6);
        rb10 = findViewById(R.id.rb10);
        rb15 = findViewById(R.id.rb15);
        rb30 = findViewById(R.id.rb30);







        if(oku("Kayit.txt") != null){
            if(oku("Kayit.txt").equals("true")){
                //Toast.makeText(getApplicationContext(), "adam", Toast.LENGTH_LONG).show();

                kayit.setChecked(true);
                kayit_bool = true;

                dusuk.setEnabled(true);


            }
            else{

                kayit.setChecked(false);
                kayit_bool = false;

                dusuk.setEnabled(false);
            }
        }


        if(oku("Onizle.txt") != null){
            if(oku("Onizle.txt").equals("true")){

                onizle.setChecked(true);
                onizle_bool = true;
            }
            else{
                onizle.setChecked(false);
                onizle_bool = false;
            }
        }


        if(oku("Dusuk.txt") != null){
            if(oku("Dusuk.txt").equals("true")){

                dusuk.setChecked(true);
                dusuk_bool = true;
            }
            else{
                dusuk.setChecked(false);
                dusuk_bool = false;
            }
        }

        if(oku("OpenCVFPS.txt") != null){
            if(oku("OpenCVFPS.txt").equals("true")){

                opencvfps.setChecked(true);
                opencvfps_bool = true;
            }
            else{
                opencvfps.setChecked(false);
                opencvfps_bool = false;
            }
        }

        String mesaj1str = "";
        String mesaj2str = "";
        if(oku("Mesaj1.txt") != null){
            mesaj1str = oku("Mesaj1.txt");
        }

        if(oku("Mesaj2.txt") != null){
            mesaj2str = oku("Mesaj2.txt");
        }



        if(oku("FPS.txt") != null){

            if(oku("FPS.txt").equals("1")){
                rb1.setChecked(true);
            }
            else if(oku("FPS.txt").equals("3")){
                rb3.setChecked(true);
            }
            else if(oku("FPS.txt").equals("5")){
                rb5.setChecked(true);
            }
            else if(oku("FPS.txt").equals("15")){
                rb15.setChecked(true);
            }
            else if(oku("FPS.txt").equals("6")){
                rb6.setChecked(true);
            }
            else if(oku("FPS.txt").equals("2")){
                rb2.setChecked(true);
            }
            else if(oku("FPS.txt").equals("10")){
                rb10.setChecked(true);
            }
            else{

                rb30.setChecked(true);

            }
        }



        kayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kayit_bool = !kayit_bool;
                if(kayit_bool){
                    dusuk.setEnabled(true);
                    yaz("Kayit.txt","true");
                }
                else{
                    dusuk.setEnabled(false);
                    yaz("Kayit.txt","false");
                }



            }
        });
        onizle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onizle_bool = !onizle_bool;
                if(onizle_bool){
                    yaz("Onizle.txt","true");
                }
                else{
                    yaz("Onizle.txt","false");
                }



            }
        });


        dusuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dusuk_bool = !dusuk_bool;
                if(dusuk_bool){
                    yaz("Dusuk.txt","true");
                }
                else{
                    yaz("Dusuk.txt","false");
                }



            }
        });
        opencvfps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencvfps_bool = !opencvfps_bool;
                if(opencvfps_bool){
                    yaz("OpenCVFPS.txt","true");
                }
                else{
                    yaz("OpenCVFPS.txt","false");
                }



            }
        });

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","1");
            }
        });
        rb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","3");
            }
        });
        rb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","5");
            }
        });
        rb15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","15");
            }
        });
        rb30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","30");
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","2");
            }
        });
        rb6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","6");
            }
        });
        rb10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yaz("FPS.txt","10");
            }
        });



        surum = findViewById(R.id.surum);
        hakkinda = findViewById(R.id.hakkindayazisi);
        surum.setOnClickListener(new View.OnClickListener() {
            boolean yazdimi = false;
            int tik = 0;
            @Override
            public void onClick(View v) {
                if(yazdimi)
                    return;

                Thread thr = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try{Thread.sleep(1000);}catch(Exception e){};
                        tik = 0;
                    }
                });thr.start();
                tik++;
                if(tik > 3){

                    hakkinda.setText(hakkinda.getText() + "\nYou are now a developer! :-)\n");
                    Toast.makeText(CameraSettings.this, ";-)", Toast.LENGTH_SHORT).show();
                    yazdimi = true;


                }


            }
        });


    }


















    //*********************************************************************************************


    //veri tabani
    //********************************************************************************************

    public String oku(String fileName){
        StringBuffer fileContent = new StringBuffer("");
        try
        {
            FileInputStream fis;
            fis = openFileInput(fileName);

            byte[] buffer = new byte[1024];

            int n = 0;
            while ((n = fis.read(buffer)) != -1)
            {
                fileContent.append(new String(buffer, 0, n));
            }


        }catch(Exception e){}
        return String.valueOf(fileContent);
    }
    public int okuInt(String fileName){


        StringBuffer fileContent = new StringBuffer("");

        FileInputStream fis = null;
        try
        {
            fis = openFileInput(fileName);
        }
        catch (FileNotFoundException e)
        {

            yaz(fileName,"0");
            return 0;
        }

        byte[] buffer = new byte[1024];

        int n = 0;
        try
        {
            while ((n = fis.read(buffer)) != -1)
            {
                fileContent.append(new String(buffer, 0, n));
            }
        }
        catch (IOException e)
        {}
        int in=0;

        try{
            in=Integer.parseInt(String.valueOf(fileContent));
        }catch(Exception e){return 0;}
        return in;
    }



    public void yaz(String fileName,String yazi){
        String testString = yazi;



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    public void ekle(String fileName,int sayi){
        sayi+=okuInt(fileName);
        String testString = sayi+"";



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    public void cikar(String fileName,int sayi){
        sayi=okuInt(fileName)-sayi;
        String testString = sayi+"";



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }



















}
