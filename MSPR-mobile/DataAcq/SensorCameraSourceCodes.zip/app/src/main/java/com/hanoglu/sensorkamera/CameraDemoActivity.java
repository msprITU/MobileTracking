
/*

Copyright (C) 2019,2020  Yusuf Kağan Hanoğlu

  This file is part of SensorCamera.

    SensorCamera is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    SensorCamera is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SensorCamera.  If not, see <https://www.gnu.org/licenses/>.*/




//Yusuf Kağan Hanoğlu 24.02.2020

/*
Bu rutin cep telefonu arayüzünden, kayda başla komutu verilerek, ayarlanabilir fps'de
avi formatında video kaydetmeye başlar ve kaydı durdur komutu alındığında kaydetmeyi
sonlandırır.
Aşağıdaki ayar seçenekleri verilmiştir.
Fps, kayda mesaj ekleme, mesajı ön izleme, kayıttaki mesaj arka planına blur ekleme ve
kayıt çözünürlüğünü düşürme

*/

package com.hanoglu.sensorkamera;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.hanoglu.sensorkamera.R;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoWriter;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class CameraDemoActivity extends Activity implements CameraBridgeViewBase.CvCameraViewListener2, SensorEventListener {


    static final int FPS = 30;
    private static final String TAG = "DEDEKTOR";




    private boolean isRecording = false;


    static double alfa = 3;


    Button captureButton;
    ImageButton settingsButton;

    static long baslanan_saniye = 0;


    public static Mat gosterilen_frame = null;




    static boolean baslamismiydi = false;
    static long threadKayitSirasi = 0;//global kayıt sırası
    static long threadKayitNumarasi = 0;

    static String threadMesaj = "";
    static String threadMesajOnemli = "";

    static final int maxThread = 5;
    static int onThread = 0;

    static int kaydedilenFrame = 0;


    public static Thread mainThread = new Thread(new Runnable() {


        boolean controlThreadPool(){


            ThreadPoolExecutor executor =
                    (ThreadPoolExecutor) Executors.newFixedThreadPool(2);



            return false;
        }


        //mainthread çalışmaya başlar, bufferdaki her frame için yeni bir thread açar, framei threade yollar ve framei siler
        @Override
        public void run() {

            threadMesaj = "READY";

            while (true) {
                while (true) {
                    if (basladimi)
                        baslamismiydi = true;

                    if (baslamismiydi) {//buffer daha önce



                        while(onThread > maxThread){
                            try{Thread.sleep(10);}catch(Exception e){}
                        }

                        if (frames.size() != 0 && frames.get(0) != null) {

                            onThread++;//açık olan thread sayısı artırıldı


                            final Mat frame = frames.remove(0);//bufferdaki framei frame matrisine yazar ve bufferdan siler
                            SensorData sensor = null;
                            final float sensorX,sensorY,sensorZ;
                            final double hizX,hizY;
                            final long sensorT;
                            if(sensors.size() != 0) {
                                sensor = sensors.remove(0);//buffer daki sensör verisini SensorData sınıfına yazar ve buffer dan siler
                                sensorX = sensor.x;
                                sensorY = sensor.y;
                                sensorZ = sensor.z;
                                sensorT = sensor.time;
                                hizX = sensor.hX;
                                hizY = sensor.hY;
                            }
                            else{
                                sensorX = 0;
                                sensorY = 0;
                                sensorZ = 0;
                                sensorT = 0;
                                hizX = 0;
                                hizY = 0;
                            }
                            final long kayitNumarasi = threadKayitNumarasi;//her threade bir kayıt sırası atanıyor
                            threadKayitNumarasi++;//bir sonraki thread için kayıt sırası artırılıyor

                            Thread thr = new Thread(new Runnable() {
                                @Override
                                public void run() {


                                    //Imgproc.putText(fr, "ivme: "+sensorX+","+sensorY+","+sensorZ+","+sensorT, new Point(10, 160), 1, 2, new Scalar(0, 0, 255, 255), 2);

                                    //Imgproc.putText(fr, "ivme: "+sensors.size(), new Point(10, 160), 1, 2, new Scalar(0, 0, 255, 255), 2);

                                    //kayıt senkronizasyonu kontrol
                                    while (kayitNumarasi != threadKayitSirasi) {//kayıt sırasını bekliyor
                                        try {
                                            Thread.sleep(0);
                                        } catch (Exception e) {
                                        }
                                    }





                                    //downsampling yapılırken buffer a <=30 fps alınır
                                    //fps yi frame tekrarı ile 30 un tam katlarına çıkarma

                                        kaydedilenFrame++;
                                        threadMesaj = "Frame: "+ kaydedilenFrame + "    Thread: "+onThread+"   Waiting: "+frames.size();

                                        Mat frame_yaz = new Mat();
                                        frame.copyTo(frame_yaz);

                                        if(!onizle_bool)
                                            gosterilen_frame = frame;
                                        else{
                                            threadMesaj += "    Will be shown: "+frames_onizleme.size();//gösterilmeyi bekleyen frameler in sayısını bildirir
                                            frames_onizleme.add(frame);

                                        }

                                        if(kayit_bool||true) {
                                            if(kayit_bool){
                                                try{

                                                    String outputVideoName = Environment.getExternalStorageDirectory()
                                                            + "/" + Environment.DIRECTORY_DCIM + "/SensorCamera/" + fileName + ".txt";

                                                    File gpxfile = new File(outputVideoName);
                                                    boolean created = false;
                                                    if(!gpxfile.exists()){
                                                        created = !created;
                                                        gpxfile.createNewFile();
                                                    }
                                                    FileWriter writer = new FileWriter(gpxfile,true);
                                                    if(created){
                                                        writer.append("Frame number: accX, accY, accZ, Time \n");
                                                    }
                                                    writer.append(threadKayitSirasi+","+sensorX+","+sensorY+","+sensorZ+","+sensorT+"\n");
                                                    writer.flush();

                                                    writer.close();
                                                }catch(Exception e){}
                                            }


                                            outputVideo.write(frame_yaz);
                                            frame_yaz = null;
                                        }





                                    threadKayitSirasi++;
                                    onThread--;

                                }
                            });
                            thr.start();
                            if(!thr.isAlive())
                                onThread--;


                        }

                        if (!basladimi && frames.size() == 0)//kayıt durdurulduğunda ve buffer boşaldığında döngüden çıkar
                            break;


                    }
                }


                while(threadKayitSirasi<threadKayitNumarasi){//tüm thread lerin sonlanması beklenir
                    try{Thread.sleep(100);}catch(Exception e){}
                }
                while(frames_onizleme.size() != 0){//tüm frameler in izlenmesini bekler
                    try{Thread.sleep(100);}catch(Exception e){}
                }


                //yeni bir kayıt için değişkenler sıfırlanır
                if(kayit_bool||true)//arayüzden kayıt istenirse
                    outputVideo.release();//yapılan kayıt sonlandırılıyor
                frames.clear();
                frames_onizleme.clear();
                sensors.clear();

                baslamismiydi = false;
                threadKayitSirasi = 0;
                threadKayitNumarasi = 0;
                frameCounter = 0;
                onThread = 0;
                kaydedilenFrame = 0;
                gosterilen_frame = null;
                frame_gorunmeye_basladi = 0;
                kayda_yeni_baslandi = true;


                threadMesajOnemli = "CAPTURE COMPLETED";


            }

        }
    });
    void showToast(String str){

        final String stri = str;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(CameraDemoActivity.this, stri, Toast.LENGTH_SHORT).show();
            }
        });

    }

    // Initialize OpenCV manager.
    private CameraBridgeViewBase mOpenCvCameraView;
    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this)  {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {

                    mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.camera_view);
                    mOpenCvCameraView.enableView();
                    break;
                }
                default: {
                    super.onManagerConnected(status);
                    break;
                }
            }
        }
    };























    Mat a;

    private SensorManager sensorManager;
    private Sensor accelerometer;

    //program çalışmaya başlıyor
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camerademo);

        SensorData[0] = 0;
        SensorData[1] = 0;
        SensorData[2] = 0;

        //sensör servisi
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);



        applicanionContext = getApplicationContext();

        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        updateFPS();//kayıt fps'ini arayüzden girilen değere ayarlar 1,2,3,5,6, gibi 30 fpsnin tam bölenleri veya katı alınmalı

        mainThread.start();//bufferı kontrol eden thread açılıyor


        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(CameraDemoActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED || ContextCompat.checkSelfPermission(CameraDemoActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            CameraDemoActivity.this,
                            new String[] { Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE },
                            1);
            try {
                Thread.sleep(100000);
            }catch (Exception e){}
        }


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            // Set up camera listener.


            mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.camera_view);
            mOpenCvCameraView.enableFpsMeter();
            if(!fpsmeter_bool)
                mOpenCvCameraView.disableFpsMeter();

            mOpenCvCameraView.setMaxFrameSize(kayit_w, kayit_h);
            mOpenCvCameraView.setVisibility(CameraBridgeViewBase.VISIBLE);
            mOpenCvCameraView.setCvCameraViewListener(this);


        }
        // Ask for camera access permission if needed
        else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        }

        // Check for writing external storage permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
        {
        }
        // Ask for writing external storage permission if needed
        else
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }


        String outputVideoName = Environment.getExternalStorageDirectory()
                + "/" + Environment.DIRECTORY_DCIM + "/SensorCamera/";

        File folder = new File(outputVideoName);
        if(!folder.exists()||folder.isFile())
            folder.mkdir();


        settingsButton = (ImageButton) findViewById(R.id.settings);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent launchNewIntent = new Intent(CameraDemoActivity.this,CameraSettings.class);
                startActivityForResult(launchNewIntent, 0);

            }
        });



        captureButton = (Button) findViewById(R.id.capturer);
        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                updateFPS();

                if(captureButton.getText().equals("Start")){

                    captureButton.setText("STOP");
                    baslanan_saniye = (int)System.currentTimeMillis()/1000;
                    frames.clear();
                    startRecording();

                }
                else if(captureButton.getText().equals("STOP")){
                    captureButton.setText("Start");
                    stopRecording();
                    baslanan_saniye = 0;


                }


            }
        });




    }

    @Override
    public void onResume() {
        super.onResume();
        updateFPS();

        //sensorManager.registerListener(this, accelerometer, 5, 1);
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);


        if (!OpenCVLoader.initDebug()) {
            // If OpenCV libraries is not loaded, trying to load it again
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_4_0, this, mLoaderCallback);
        } else {
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }





    }
    @Override
    public void onPause() {
        updateFPS();


        super.onPause();

    }

    private void updateFPS(){

        if(oku("FPS.txt").equals("1") || oku("FPS.txt").equals("3") || oku("FPS.txt").equals("5") || oku("FPS.txt").equals("15") || oku("FPS.txt").equals("30") || oku("FPS.txt").equals("2") || oku("FPS.txt").equals("6") || oku("FPS.txt").equals("10") || oku("FPS.txt").equals("60") || oku("FPS.txt").equals("90") || oku("FPS.txt").equals("120") || oku("FPS.txt").equals("1200") || oku("FPS.txt").equals("3000"))
        {
            istenilenFps = Integer.parseInt(oku("FPS.txt"));
        }
        else
            istenilenFps = 30;


        if(oku("Mesaj1.txt") != null){
            mesaj1str = oku("Mesaj1.txt");
        }



        if(oku("Kayit.txt") != null){
            if(oku("Kayit.txt").equals("true")){
                kayit_bool = true;
            }
            else{
                kayit_bool = false;
            }
        }



        if(oku("Onizle.txt") != null){
            if(oku("Onizle.txt").equals("true")){
                onizle_bool = true;
            }
            else{
                onizle_bool = false;
            }
        }
        if(oku("Onizle2.txt") != null){
            if(oku("Onizle2.txt").equals("true")){
                onizle2_bool = true;
            }
            else{
                onizle2_bool = false;
            }
        }
        if(oku("OpenCVFPS.txt") != null){
            if(oku("OpenCVFPS.txt").equals("true")){
                fpsmeter_bool = true;
            }
            else{
                fpsmeter_bool = false;
            }
        }

        if(oku("Dusuk.txt") != null){
            if(oku("Dusuk.txt").equals("true")){

                    kayit_w = 256;
                    kayit_h = 144;

            }
            else{
                kayit_w = 1280;
                kayit_h = 720;

            }
        }






    }





    static String mesaj1str = "";
    static boolean kayit_bool = false;
    static boolean onizle_bool = false;
    static boolean onizle2_bool = false;
    static boolean fpsmeter_bool = false;








    static long frameCounter = 0;
    static boolean basladimi = false;


    private void startCameraListener() {
        // set up camera listener.
        mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.camera_view);
        mOpenCvCameraView.enableFpsMeter();
        if(!fpsmeter_bool)
            mOpenCvCameraView.disableFpsMeter();
        mOpenCvCameraView.setMaxFrameSize(kayit_w, kayit_h);
        mOpenCvCameraView.setVisibility(CameraBridgeViewBase.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);

    }


    int frameWidth = 0; int frameHeight = 0;
    public void onCameraViewStarted(int width, int height) {
        // initialize frame size
        frameWidth = width;
        frameHeight = height;
    }

    static List<Mat> frames = new LinkedList<Mat>();
    static List<SensorData> sensors = new LinkedList<SensorData>();
    static List<Mat> frames_onizleme = new LinkedList<Mat>();//önizleme için fps senkronizasyonu



    public static long frame_gorunmeye_basladi = 0;
    public static boolean kayda_yeni_baslandi = true;

    static int threadMesajSure = 0;
    String threadOncekiMesaj = "";
    String threadOncekiMesajOnemli = "";
    static long OncekiSensorZaman = 0;
    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {

        Mat frame = inputFrame.rgba();  // get a new frame


        //yaklasik 30 fps
        Imgproc.cvtColor(frame, frame, Imgproc.COLOR_RGBA2BGR);  // color space change to record

        // save rich video frame by frame

        Mat yazdir = new Mat();//yazdir matrisine kameradan gelen matris kopyalanır
        //frame.copyTo(yazdir);
        Imgproc.resize(frame, yazdir, new Size(kayit_w,kayit_h),0,0,Imgproc.INTER_AREA);


        if(basladimi){//kayda başlanmışsa buffer lama açılır


            //downsampling yapılır
            if(istenilenFps <= 30) {//1 2 3 5 6 10 15 30
                int gecikme = FPS / istenilenFps;


                if (frameCounter % gecikme == 0) {

                    SensorData sd = new SensorData(SensorData);

                    if(OncekiSensorZaman != 0){
                        sd.setT(System.currentTimeMillis()-OncekiSensorZaman);
                    }

                    OncekiSensorZaman = System.currentTimeMillis();
                    sd.setHX(AnlikHizX);
                    sd.setHY(AnlikHizY);

                    frames.add(yazdir);

                    sensors.add(sd);


                }

            }

            else{// 60 90 120
                //int gecikme = istenilenFps/FPS;

                //for (int a = 0; a < gecikme; a++) {

                frames.add(yazdir);

                //}
            }





            frameCounter = frameCounter + 1;

        }

        if(onizle_bool){//onizlemede fps senkronizasyonuna zorlanıyorsa
            if(frame_gorunmeye_basladi == 0)//değişkene ilk defa değer atanır
                frame_gorunmeye_basladi = System.currentTimeMillis();//değerler milisaniye olarak atanır
            long gecen_zaman = System.currentTimeMillis() - frame_gorunmeye_basladi;//zaman farkı alınır

            boolean devam_et = true;
            if(onizle2_bool) {
                if (frames_onizleme.size() == 0)
                    kayda_yeni_baslandi = true;//eğer buffer bitti ise buffer ın 3 saniye daha stoklaması için bekle
                if (kayda_yeni_baslandi) {
                    if (frames_onizleme.size() < 3 * istenilenFps)
                        devam_et = false;//senkronizasyon için, buffer ın büyüklüğünün 3 saniye sürecek bir önizlemeye sahip olmasını bekler
                    else
                        kayda_yeni_baslandi = false;

                }
            }

            if(devam_et && (1000/istenilenFps) <= gecen_zaman && frames_onizleme.size() != 0 && frames_onizleme.get(0) != null){//buffer da gösterilecek frame var ve bu frame in gösterim zamanı gelmişse frame i göster

                gosterilen_frame = frames_onizleme.remove(0).clone();//onizleme buffer ından veriyi çeker ve çektiği veriyi siler
                frame_gorunmeye_basladi = System.currentTimeMillis();//yeni gösterilecek frame için gösterime başlama zamanı alınır

            }



        }




        if(gosterilen_frame != null) {
            //Kayıt yapılırken yapılacak değişim
            frame = gosterilen_frame;
            Imgproc.cvtColor(frame, frame, Imgproc.COLOR_RGBA2BGR);  // color space change to display

        }
        else//Kayıt yapılmadığı zaman yapılacak değişim
            Imgproc.cvtColor(frame, frame, Imgproc.COLOR_BGR2RGB);  // color space change to display



        if(kayit_bool|| true) {//arayüzden önizleme aktive edilir
            Imgproc.putText(frame, mesaj1str, new Point(50, 350), 3, 10, new Scalar(255, 0, 0, 255), 4);
        }

        //arayüzde fps gösterilir
        Imgproc.putText(frame, istenilenFps+" FPS  "+kayit_w+"*"+kayit_h, new Point(10, 40), 1, 3, new Scalar(0, 0, 255, 255), 3);

        //arayüzde yapılan kayıt uzunluğu saniye olarak gösterilir
        if(baslanan_saniye != 0) {
            long l = (int)System.currentTimeMillis()/1000 - baslanan_saniye;
            Imgproc.putText(frame, l + ". SEC", new Point(10, 80), 1, 2, new Scalar(0, 0, 255, 255), 2);
        }

        //arayüzde gösterilen mesajların kontrolü
        //arayüzdeki uyarı mesajları 3 saniye gösterilir
        if(!threadOncekiMesaj.equals(threadMesaj))
            threadMesajSure = 0;
        if(!threadOncekiMesajOnemli.equals(threadOncekiMesajOnemli)) {
            threadMesajSure = 0;
            threadMesaj = "";
        }

        if(threadMesajSure <= 60 && (!threadMesaj.equals("") || !threadMesajOnemli.equals(""))){
            if(threadMesajOnemli.equals(""))
                Imgproc.putText(frame, threadMesaj, new Point(10, 120), 1, 2, new Scalar(0, 0, 255, 255), 2);
            else {
                Scalar sc = new Scalar(0,0,255,255);
                if(threadMesajSure%20 > 10)
                    sc = new Scalar(255,0,0,255);

                Imgproc.putText(frame, threadMesajOnemli, new Point(10, 120), 1, 2, sc, 2);
            }


        }
        else{
            threadMesaj = "";
            threadMesajOnemli = "";
            threadMesajSure = 0;

        }
        threadMesajSure++;
        threadOncekiMesaj = threadMesaj;
        threadOncekiMesajOnemli = threadMesajOnemli;



        return frame;



    }


    public static int kayit_w = 1280;
    public static int kayit_h = 720;

    public static int istenilenFps = 3;
    private void stopRecording() {
        basladimi = false;



        /*if(istenilenFps <= 30) {//1 2 3 5 6 10 15 30
            int gecikme = FPS / istenilenFps;

            for (int i = 0, j = 0; i < frames.size(); i++) {

                if (i % gecikme == 0) {
                    j++;

                    if (j % istenilenFps == 0) {
                        if (kayit_bool) {
                            if (blur_bool)
                                Imgproc.blur(frames.get(i), frames.get(i), frames.get(i).size());
                            Imgproc.putText(frames.get(i), mesaj1str, new Point(50, 350), 3, 10, new Scalar(0, 0, 255, 30), 4);
                            Imgproc.putText(frames.get(i), mesaj2str, new Point(240, 580), 3, 6, new Scalar(0, 0, 255, 30), 4);
                        }

                        j = 0;
                    }
                    outputVideo.write(frames.get(i));
                }

                //frames.remove(i);
            }
        }
        else{// 60 90 120
            int gecikme = istenilenFps/FPS;

            for (int i = 0, j = 0; i < frames.size(); i++) {


                for (int a = 0; a < gecikme; a++){
                        j++;
                        if (j % istenilenFps == 0) {
                            if (kayit_bool) {
                                if (blur_bool)
                                    Imgproc.blur(frames.get(i), frames.get(i), frames.get(i).size());
                                Imgproc.putText(frames.get(i), mesaj1str, new Point(50, 350), 3, 10, new Scalar(0, 0, 255, 30), 4);
                                Imgproc.putText(frames.get(i), mesaj2str, new Point(240, 580), 3, 6, new Scalar(0, 0, 255, 30), 4);
                            }
                            j = 0;
                        }
                        outputVideo.write(frames.get(i));
                    }


                //frames.remove(i);
            }
        }




        outputVideo.release();  // close the output video

        // showing the name and the path to the user as a toast message
        Toast.makeText(this, "Kayıt Tamamlandı", Toast.LENGTH_SHORT).show();


        */
    }
    public void onCameraViewStopped() {
    }



























    static VideoWriter outputVideo;




    static String fileName = "";
    private void startRecording() {

        updateFPS();
        frameCounter = 0;

        // formatting the file name and path (to gallery as jpg)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateAndTime = sdf.format(new Date());
        fileName = "sampleCV_" + currentDateAndTime;

        // Updating the Folder, 15.10.2019 - 07:46

        String outputVideoName = Environment.getExternalStorageDirectory()
                + "/" + Environment.DIRECTORY_DCIM + "/SensorCamera/" + fileName + ".avi";

        if(kayit_bool||true) {//kayıt yapılacaksa outputVideo başlatılır
            outputVideo = new VideoWriter();


            // Check for writing external storage permission
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {


                // open the output video
                outputVideo.open(outputVideoName,
                        VideoWriter.fourcc('M', 'J', 'P', 'G'), istenilenFps, new Size(kayit_w, kayit_h));//frameWidth, frameHeight));


            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }


            // check the output video
            if (outputVideo.isOpened()) {
                Toast.makeText(this, "Capture Started", Toast.LENGTH_SHORT).show();

                basladimi = true;

            }
        }else{
            Toast.makeText(this, "Capture Started", Toast.LENGTH_SHORT).show();

            basladimi = true;
        }


    }












    // Upload file to storage and return a path.
    private static String getPath(String file, Context context) {
        AssetManager assetManager = context.getAssets();
        BufferedInputStream inputStream = null;
        try {
            // Read data from assets.
            inputStream = new BufferedInputStream(assetManager.open(file));
            byte[] data = new byte[inputStream.available()];
            inputStream.read(data);
            inputStream.close();
            // Create copy file in storage.
            File outFile = new File(context.getFilesDir(), file);
            FileOutputStream os = new FileOutputStream(outFile);
            os.write(data);
            os.close();
            Log.i(TAG, "File loaded successfully");
            // Return a path to file which may be read in common way.
            return outFile.getAbsolutePath();
        } catch (IOException ex) {
            Log.i(TAG, "Failed to upload a file");
        }
        return "";
    }








    private static Context applicanionContext;























































    //veri tabani
    //********************************************************************************************

    public String oku(String fileName){
        StringBuffer fileContent = new StringBuffer("");
        try
        {
            FileInputStream fis;
            fis = openFileInput(fileName);

            byte[] buffer = new byte[1024];

            int n = 0;
            while ((n = fis.read(buffer)) != -1)
            {
                fileContent.append(new String(buffer, 0, n));
            }


        }catch(Exception e){}
        return String.valueOf(fileContent);
    }
    public int okuInt(String fileName){


        StringBuffer fileContent = new StringBuffer("");

        FileInputStream fis = null;
        try
        {
            fis = openFileInput(fileName);
        }
        catch (FileNotFoundException e)
        {

            yaz(fileName,"0");
            return 0;
        }

        byte[] buffer = new byte[1024];

        int n = 0;
        try
        {
            while ((n = fis.read(buffer)) != -1)
            {
                fileContent.append(new String(buffer, 0, n));
            }
        }
        catch (IOException e)
        {}
        int in=0;

        try{
            in=Integer.parseInt(String.valueOf(fileContent));
        }catch(Exception e){return 0;}
        return in;
    }



    public void yaz(String fileName,String yazi){
        String testString = yazi;



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    public void ekle(String fileName,int sayi){
        sayi+=okuInt(fileName);
        String testString = sayi+"";



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    public void cikar(String fileName,int sayi){
        sayi=okuInt(fileName)-sayi;
        String testString = sayi+"";



        FileOutputStream fos;

        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(testString.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }


    static float SensorData[] = new float[3];//x,y ve z
    long previousTime = 0L;
    long currentTime = 0L;
    long deltaTimeInMs = 0L;
    float deltaTime = 0f;
    boolean isFirstTimeRead = true;
    boolean isFound = false;
    private float totalTime;
    private int periodCounter = 0;
    long currentTimeFPS = 0L;
    long lastTimeFPS = 0L;
    float fps = 0f;
    float[] camVel = new float[3];
    float[] camPos = new float[3];
    float[] cpt = new float[3];
    int alpha = 5;


    static double AnlikHizX = 0;
    static double AnlikHizY = 0;

    static boolean ilkanlikhiz = false;

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION && basladimi) {
            // take accelerometer data
            SensorData = event.values;
        }
    }

    class SensorData {

        float x = 3;
        float y = 3;
        float z = 3;

        double hX = 0;
        double hY = 0;
        double hZ = 0;

        long time = 0;
        public SensorData(){

        }
        public SensorData(float[] f){
            x = f[0];
            y = f[1];
            z = f[2];


        }
        public float setX(float a){
            x = a;
            return x;
        }
        public float setY(float a){
            y = a;
            return y;
        }
        public float setZ(float a){
            z = a;
            return z;
        }
        public long setT(long t){
            time = t;
            return time;
        }
        public double setHX(double hizX){
            hX = hizX;
            return hX;
        }
        public double setHY(double hizY){
            hY = hizY;
            return hY;
        }
        public double setHZ(double hizZ){
            hZ = hizZ;
            return hZ;
        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
